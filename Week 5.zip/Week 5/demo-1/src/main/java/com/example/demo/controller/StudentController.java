package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Student;
import com.example.demo.repository.StudentRepository;

@Controller
public class StudentController {

    @Autowired
    private StudentRepository repo;

    @GetMapping("/")
    public String form(org.springframework.ui.Model model) {
        model.addAttribute("student", new Student());
        return "index";
    }

    @PostMapping("/save")
    public String save(Student student) {
        repo.save(student);
        return "redirect:/students";
    }
    
    @GetMapping("/students")
    public String listStudents(org.springframework.ui.Model model) {
        model.addAttribute("students", repo.findAll());
        return "students";
    }

}
